export class [Module]Dto {
  address_id: string;
  address_type: string;
  primary: boolean;
  address_1: string;
  city: string;
  region: string;
  country: string;
  address_postalcode: string;
}
