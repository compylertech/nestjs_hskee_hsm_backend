export class Create[Module]Dto {
  address_type: string;
  primary: boolean;
  address_1: string;
  address_2: string;
  city: string;
  region: string;
  country: string;
  address_postalcode: string;
}
