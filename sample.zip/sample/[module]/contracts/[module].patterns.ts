export const [MODULE]_PATTERN = {
    FIND_ALL: 'address.findAll',
    FIND_ONE: 'address.findOne',
    CREATE: 'address.create',
    UPDATE: 'address.update',
    REMOVE: 'address.remove'
}